#' igraph Compatibility Layer
#' 
#' This file provides compatibility functions to handle both old and new igraph API
#' ensuring MONECA works with igraph versions from 1.3.0 onwards
#' 
#' @keywords internal

# Check igraph version and set up appropriate function mappings
.onLoad <- function(libname, pkgname) {
  igraph_version <- utils::packageVersion("igraph")
  
  # Version 1.3.0 introduced the new API with underscore notation
  if (igraph_version >= "1.3.0") {
    # Map old functions to new ones in the package namespace
    
    # Graph creation
    assign("graph.adjacency.compat", 
           function(...) igraph::graph_from_adjacency_matrix(...),
           envir = parent.env(environment()))
    
    # Graph analysis
    assign("get.edgelist.compat", 
           function(...) igraph::as_edgelist(...),
           envir = parent.env(environment()))
    
    assign("graph.density.compat", 
           function(...) igraph::edge_density(...),
           envir = parent.env(environment()))
    
    assign("shortest.paths.compat", 
           function(...) igraph::distances(...),
           envir = parent.env(environment()))
    
    assign("average.path.length.compat", 
           function(...) igraph::mean_distance(...),
           envir = parent.env(environment()))
    
    assign("clusters.compat", 
           function(...) igraph::components(...),
           envir = parent.env(environment()))
    
  } else {
    # Use old functions for older igraph versions
    assign("graph.adjacency.compat", igraph::graph.adjacency,
           envir = parent.env(environment()))
    
    assign("get.edgelist.compat", igraph::get.edgelist,
           envir = parent.env(environment()))
    
    assign("graph.density.compat", igraph::graph.density,
           envir = parent.env(environment()))
    
    assign("shortest.paths.compat", igraph::shortest.paths,
           envir = parent.env(environment()))
    
    assign("average.path.length.compat", igraph::average.path.length,
           envir = parent.env(environment()))
    
    assign("clusters.compat", igraph::clusters,
           envir = parent.env(environment()))
  }
  
  # Handle norm_coords which was removed in newer versions
  if (!exists("norm_coords", where = asNamespace("igraph"), mode = "function")) {
    assign("norm_coords.compat", 
           function(layout, xmin = -1, xmax = 1, ymin = -1, ymax = 1) {
             # Normalize layout coordinates to specified range
             if (ncol(layout) != 2) {
               stop("Layout must be a two-column matrix")
             }
             
             # Scale x coordinates
             x_range <- range(layout[, 1])
             if (x_range[1] != x_range[2]) {
               layout[, 1] <- (layout[, 1] - x_range[1]) / 
                              (x_range[2] - x_range[1]) * 
                              (xmax - xmin) + xmin
             }
             
             # Scale y coordinates  
             y_range <- range(layout[, 2])
             if (y_range[1] != y_range[2]) {
               layout[, 2] <- (layout[, 2] - y_range[1]) / 
                              (y_range[2] - y_range[1]) * 
                              (ymax - ymin) + ymin
             }
             
             return(layout)
           },
           envir = parent.env(environment()))
  } else {
    assign("norm_coords.compat", igraph::norm_coords,
           envir = parent.env(environment()))
  }
}

#' Compatibility wrapper for creating graphs from adjacency matrices
#' @keywords internal
#' @export
moneca_graph_from_adjacency <- function(...) {
  graph.adjacency.compat(...)
}

#' Compatibility wrapper for getting edge lists
#' @keywords internal
#' @export
moneca_get_edgelist <- function(...) {
  get.edgelist.compat(...)
}

#' Compatibility wrapper for graph density
#' @keywords internal
#' @export
moneca_graph_density <- function(...) {
  graph.density.compat(...)
}

#' Compatibility wrapper for shortest paths
#' @keywords internal
#' @export
moneca_shortest_paths <- function(...) {
  shortest.paths.compat(...)
}

#' Compatibility wrapper for average path length
#' @keywords internal
#' @export
moneca_average_path_length <- function(...) {
  average.path.length.compat(...)
}

#' Compatibility wrapper for graph components
#' @keywords internal
#' @export
moneca_components <- function(...) {
  clusters.compat(...)
}

#' Compatibility wrapper for norm_coords
#' @keywords internal
#' @export
moneca_norm_coords <- function(...) {
  norm_coords.compat(...)
}