#' Migration script for updating deprecated igraph functions
#' 
#' This script contains the logic to update all deprecated igraph functions
#' to use the compatibility layer, ensuring both backward and forward compatibility
#' 
#' @keywords internal

# Define the mapping of old to new function calls
igraph_migration_map <- list(
  # Direct replacements using compatibility layer
  "graph\\.adjacency\\(" = "moneca_graph_from_adjacency(",
  "get\\.edgelist\\(" = "moneca_get_edgelist(",
  "graph\\.density\\(" = "moneca_graph_density(",
  "shortest\\.paths\\(" = "moneca_shortest_paths(",
  "average\\.path\\.length\\(" = "moneca_average_path_length(",
  "clusters\\(" = "moneca_components(",
  "norm_coords\\(" = "moneca_norm_coords(",
  
  # These remain unchanged as they're still valid
  # "cliques\\(" = "cliques(",
  # "degree\\(" = "degree(",
  # "vcount\\(" = "vcount(",
  # "ecount\\(" = "ecount(",
  # "diameter\\(" = "diameter(",
  # "betweenness\\(" = "betweenness(",
  # "closeness\\(" = "closeness(",
  # "simplify\\(" = "simplify("
)

#' Apply igraph function migrations to a file
#' 
#' @param file_path Path to the R file to migrate
#' @return Logical indicating success
#' @keywords internal
migrate_igraph_in_file <- function(file_path) {
  # Read the file
  content <- readLines(file_path)
  original_content <- content
  
  # Apply each migration
  for (old_pattern in names(igraph_migration_map)) {
    new_replacement <- igraph_migration_map[[old_pattern]]
    content <- gsub(old_pattern, new_replacement, content)
  }
  
  # Check if any changes were made
  if (!identical(content, original_content)) {
    writeLines(content, file_path)
    message("Updated igraph functions in: ", basename(file_path))
    return(TRUE)
  }
  
  return(FALSE)
}

#' Run the migration on all R files in the package
#' 
#' @param dry_run If TRUE, only report what would be changed
#' @return List of files that were (or would be) modified
#' @keywords internal
#' @export
migrate_all_igraph_functions <- function(dry_run = FALSE) {
  # Get all R files in the package
  r_files <- list.files("R", pattern = "\\.R$", full.names = TRUE)
  
  # Exclude our own compatibility and migration files
  r_files <- r_files[!basename(r_files) %in% 
                     c("igraph_compatibility.R", "migrate_igraph_functions.R")]
  
  modified_files <- character()
  
  for (file in r_files) {
    if (dry_run) {
      # Just check if file would be modified
      content <- readLines(file)
      for (old_pattern in names(igraph_migration_map)) {
        if (any(grepl(old_pattern, content))) {
          modified_files <- c(modified_files, file)
          message("Would update: ", basename(file))
          break
        }
      }
    } else {
      # Actually perform the migration
      if (migrate_igraph_in_file(file)) {
        modified_files <- c(modified_files, file)
      }
    }
  }
  
  if (length(modified_files) > 0) {
    message("\nTotal files ", ifelse(dry_run, "to be ", ""), 
            "modified: ", length(modified_files))
  } else {
    message("\nNo files need modification.")
  }
  
  invisible(modified_files)
}

#' Generate a report of igraph function usage
#' 
#' @return Data frame with function usage statistics
#' @keywords internal
#' @export
analyze_igraph_usage <- function() {
  r_files <- list.files("R", pattern = "\\.R$", full.names = TRUE)
  
  # All igraph functions we're interested in
  all_functions <- c(names(igraph_migration_map),
                     "cliques\\(", "degree\\(", "vcount\\(", "ecount\\(",
                     "diameter\\(", "betweenness\\(", "closeness\\(", 
                     "simplify\\(", "E\\(", "V\\(", "layout_with_fr\\(")
  
  usage_stats <- data.frame(
    function_name = character(),
    file = character(),
    line_number = integer(),
    deprecated = logical(),
    stringsAsFactors = FALSE
  )
  
  for (file in r_files) {
    content <- readLines(file)
    
    for (i in seq_along(content)) {
      for (func_pattern in all_functions) {
        if (grepl(func_pattern, content[i])) {
          func_name <- gsub("\\\\\\(", "", func_pattern)
          is_deprecated <- func_pattern %in% names(igraph_migration_map)
          
          usage_stats <- rbind(usage_stats, data.frame(
            function_name = func_name,
            file = basename(file),
            line_number = i,
            deprecated = is_deprecated,
            stringsAsFactors = FALSE
          ))
        }
      }
    }
  }
  
  return(usage_stats)
}