# MONECA
MONECA - Mobility Network Clustering Algorithm  
Requires R and you can install it with devtools.  

install.packages("devtools")  
library(devtools)  
install_github("antongrau/MONECA")  
