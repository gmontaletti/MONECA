# Test fix for moneca.plot matrix error

# Source the functions directly since install is not working
source("R/igraph_compatibility.R")
source("R/synthetic_data.R")  
source("R/analytical_functions.R")
source("R/descriptive_functions.R")

# Load required packages
library(igraph)

# Create test data similar to the user's scenario
set.seed(123)
test_data <- generate_mobility_data(n_classes = 10, n_total = 5000)

# Run MONECA analysis
cat("Running MONECA analysis...\n")
seg <- moneca(test_data, segment.levels = 3, mode = "Mutual", small.cell.reduction = 5)

# Test the moneca.plot function - this was failing before
cat("Testing moneca.plot()...\n")
tryCatch({
  moneca.plot(seg)
  cat("SUCCESS: moneca.plot() worked without errors!\n")
}, error = function(e) {
  cat("ERROR in moneca.plot():", e$message, "\n")
})

# Also test the functions that call weight.matrix
cat("Testing layout.matrix()...\n")
tryCatch({
  layout <- layout.matrix(seg)
  cat("SUCCESS: layout.matrix() worked!\n")
}, error = function(e) {
  cat("ERROR in layout.matrix():", e$message, "\n")
})

cat("Testing segment.edges()...\n")
tryCatch({
  edges <- segment.edges(seg)
  cat("SUCCESS: segment.edges() worked!\n")
}, error = function(e) {
  cat("ERROR in segment.edges():", e$message, "\n")
})