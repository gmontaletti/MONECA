library(testthat)
library(moneca)

test_check("moneca")