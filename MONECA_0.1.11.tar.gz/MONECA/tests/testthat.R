library(testthat)
library(MONECA)

test_check("MONECA")